package infoware.vedika.vedika;

import org.springframework.data.jpa.repository.JpaRepository;


public interface Employee_Repo extends JpaRepository<Employee,Integer> {

}
